Xenblocks Core
==============

http://www.xenblocks.com

What is Xenblocks?
------------------

Xenblocks is an experimental digital currency that enables instant payments to
anyone, anywhere in the world. Xenblocks uses peer-to-peer technology to operate
with no central authority: managing transactions and issuing money are carried
out collectively by the network. Xenblocks Core is the name of open source
software which enables the use of this currency.

For more information, as well as an immediately useable, binary version of
the Xenblocks Core software, see [http://www.xenblocks.com](http://www.xenblocks.com).

Documentation
-------------

Xenblocks is based on the Litecoin cryptocurrency code base, which is based on the bitcoin
code base. All current Bitcoin and Litecoin documentation up to version 0.13.3 is 100%
compatible with Xenblocks.

See the following links to learn more about Bitcoin/Litecoin/Xenblocks:

- [https://www.reddit.com/r/BitcoinBeginners/](https://www.reddit.com/r/BitcoinBeginners/)
- [https://en.bitcoin.it/wiki/Running_Bitcoin](https://en.bitcoin.it/wiki/Running_Bitcoin)
- [https://bitcoin.org/en/developer-documentation](https://bitcoin.org/en/developer-documentation)


Quick Guide
-----------

Xenblocks distributes the following binaries available for Windows, Mac & Linux:

- Xenblocks-Qt (Xenblocks GUI wallet)
- xenblocksd (Xenblocks daemon processes, connected to peer to peer network)
- xenblocks-cli (Xenblocks command line interface to connect with daemon process)
- xenblocks-tx (Xenblocks utility command)

For a list of useful commands use the --help argument:

```
$ xenblocksd --help
```

```
$ xenblocks-cli --help
```

```
$ xenblocks-tx --help
```
